﻿jQuery(document).ready(function(){
	
	/* 메뉴슬라이드 위  아래 내리기 */
	$('.submenu').slideUp(0);
	
	$('.mainBtn').on({
		mouseover:function(){
			$('.submenu').stop().slideUp(300);
			$(this).next().stop().slideDown(300);
		}
	});
	$('.header-right>ul>li').on({
		mouseleave:function(){
			$(this).children('.submenu').hide(0);
		}
	});
	
	/* slide */
	var s=[];
		s[0]=1;
		
		setInterval(nextSlideIf,3000);
		function nextSlideIf(){
			
			if(s[0]==1){
				slide(1);
			}
			else if(s[1]==1){
				slide(2);
			}
			else if(s[2]==1){
				slide(0);
			}
		}
		
	function slide(z){
		s=[0,0,0];
		s[z]=1;
		
		if(z==0){
			$('.slide').eq(2).stop().animate({left:  '0%'},0).animate({left:'-100%'},1000);
			$('.slide').eq(0).stop().animate({left:'100%'},0).animate({left:   '0%'},1000);
			$('.slide').eq(1).stop().animate({left:'200%'},0).animate({left: '100%'},1000);
		}
		else if(z==1){
			$('.slide').eq(0).stop().animate({left:  '0%'},0).animate({left:'-100%'},1000);
			$('.slide').eq(1).stop().animate({left:'100%'},0).animate({left:   '0%'},1000);
			$('.slide').eq(2).stop().animate({left:'200%'},0).animate({left: '100%'},1000);
		}
		else if(z==2){
			$('.slide').eq(1).stop().animate({left:  '0%'},0).animate({left:'-100%'},1000);
			$('.slide').eq(2).stop().animate({left:'100%'},0).animate({left:   '0%'},1000);
			$('.slide').eq(0).stop().animate({left:'200%'},0).animate({left: '100%'},1000);
		}
	}
	
	
	
	/* 탭버튼  */
	$('#c_tab1').show();
	$('#c_tab2').hide();
	
	$('.tabBtn1').on({
		click:function(){
			$('#c_tab1').show();
			$('#c_tab2').hide();
		}
	});
	$('.tabBtn2').on({
		click:function(){
			$('#c_tab1').hide();
			$('#c_tab2').show();
		}
	});
	
	
	/* modal  */
	
	$('.modalBtn').on({
		click:function(){
			$('#modal').show();
			$('html').addClass('addScroll');
		}
	});
	
	$('.mCloseBtn').on({
		click:function(){
			$('#modal').hide();
			$('html').removeClass('addScroll');
		}
	});
	
	
	
});